Трассировщики (Linux x86_64), сборка из коммита 455d1a4:
usftrace, sidtrace, spctrace, vgm2wav - кладутся рядом со скриптами конвертации
(usf_tracer/, sid_tracer/, spc_tracer/, vgm_render/).
